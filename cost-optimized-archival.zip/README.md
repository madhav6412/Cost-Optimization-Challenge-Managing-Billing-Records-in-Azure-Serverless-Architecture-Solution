# Cost Optimized Archival with Azure

This repo demonstrates how to optimize storage cost by archiving old data from Azure Cosmos DB to Azure Blob Storage using Azure Data Factory pipelines.
